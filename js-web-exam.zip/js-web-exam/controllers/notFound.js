module.exports = {
    notFound(req, res) {
        res.render('404')
    }
}