module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING: 'mongodb://localhost:27017/final-exam-db',
    TOKEN_SECRET: 'this is very secure',
    COOKIE_NAME: 'SESSION_TOKEN',

}

// TODO: FIX DB NAME